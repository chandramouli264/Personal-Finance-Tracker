// Pure logic (no DOM) so it can be unit-tested with Node.
export const CATEGORIES = {
  expense: ["Food", "Transport", "Rent", "Bills", "Shopping", "Health", "Entertainment", "Other"],
  income: ["Salary", "Freelance", "Gift", "Other"],
};

const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

export function validateEntry({ type, description, amount, category, date }) {
  const errors = {};
  if (!["income", "expense"].includes(type)) errors.type = "Choose income or expense";
  if (!description || !description.trim()) errors.description = "Enter a description";
  const n = Number(amount);
  if (amount === "" || amount === null || amount === undefined || !Number.isFinite(n) || n <= 0)
    errors.amount = "Enter an amount greater than 0";
  if (!CATEGORIES[type] || !CATEGORIES[type].includes(category)) errors.category = "Choose a category";
  if (!date || Number.isNaN(Date.parse(date))) errors.date = "Pick a date";
  return { ok: Object.keys(errors).length === 0, errors };
}

export function createEntry(input, id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`) {
  return {
    id,
    type: input.type,
    description: input.description.trim(),
    amount: round2(Number(input.amount)),
    category: input.category,
    date: input.date,
  };
}

export function totals(entries) {
  let income = 0, expense = 0;
  for (const e of entries) (e.type === "income" ? (income += e.amount) : (expense += e.amount));
  income = round2(income); expense = round2(expense);
  return { income, expense, balance: round2(income - expense) };
}

/** Expense totals per category, largest first, with each one's share of all spending. */
export function expenseByCategory(entries) {
  const map = new Map();
  for (const e of entries) if (e.type === "expense") map.set(e.category, (map.get(e.category) || 0) + e.amount);
  const total = [...map.values()].reduce((a, b) => a + b, 0);
  return [...map.entries()]
    .map(([category, amount]) => ({ category, amount: round2(amount), share: total ? amount / total : 0 }))
    .sort((a, b) => b.amount - a.amount);
}

/** filters: { type: 'all'|'income'|'expense', month: 'YYYY-MM' | '' } */
export function filterEntries(entries, { type = "all", month = "" } = {}) {
  return entries
    .filter((e) => (type === "all" || e.type === type) && (!month || e.date.startsWith(month)))
    .sort((a, b) => b.date.localeCompare(a.date));
}

export const formatMoney = (n) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(n);
