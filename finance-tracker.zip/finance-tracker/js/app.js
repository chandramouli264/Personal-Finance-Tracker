import { CATEGORIES, createEntry, expenseByCategory, filterEntries, formatMoney, totals, validateEntry } from "./ledger.js";

const KEY = "finance-tracker:entries";
const $ = (id) => document.getElementById(id);

function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; }
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(entries)); } catch { /* storage unavailable: keep in memory */ }
}

let entries = load();
const filters = { type: "all", month: "" };

const form = $("entry-form");
const typeInputs = form.querySelectorAll('input[name="type"]');
const selectedType = () => form.querySelector('input[name="type"]:checked').value;

function fillCategories() {
  const sel = $("category");
  sel.replaceChildren(...CATEGORIES[selectedType()].map((c) => new Option(c, c)));
}

function render() {
  const t = totals(entries);
  $("balance").textContent = formatMoney(t.balance);
  $("balance").classList.toggle("neg", t.balance < 0);
  $("income").textContent = formatMoney(t.income);
  $("expense").textContent = formatMoney(t.expense);

  const rows = filterEntries(entries, filters);
  const list = $("list");
  list.replaceChildren();
  $("empty").hidden = rows.length > 0;
  for (const e of rows) {
    const li = document.createElement("li");
    li.className = e.type;
    const main = document.createElement("div");
    const title = document.createElement("strong"); title.textContent = e.description;
    const meta = document.createElement("span"); meta.className = "meta"; meta.textContent = `${e.category}, ${e.date}`;
    main.append(title, meta);
    const amt = document.createElement("span"); amt.className = "amt";
    amt.textContent = `${e.type === "income" ? "+" : "-"}${formatMoney(e.amount)}`;
    const del = document.createElement("button");
    del.type = "button"; del.className = "link"; del.textContent = "Delete";
    del.setAttribute("aria-label", `Delete ${e.description}`);
    del.addEventListener("click", () => { entries = entries.filter((x) => x.id !== e.id); save(); render(); });
    li.append(main, amt, del);
    list.append(li);
  }

  const bars = $("bars");
  bars.replaceChildren();
  const cats = expenseByCategory(filterEntries(entries, { type: "expense", month: filters.month }));
  $("no-cats").hidden = cats.length > 0;
  for (const c of cats) {
    const row = document.createElement("div"); row.className = "bar-row";
    const label = document.createElement("span"); label.textContent = c.category;
    const track = document.createElement("div"); track.className = "track";
    const fill = document.createElement("div"); fill.className = "fill"; fill.style.width = `${Math.max(2, c.share * 100)}%`;
    track.append(fill);
    const val = document.createElement("span"); val.className = "val";
    val.textContent = `${formatMoney(c.amount)} (${Math.round(c.share * 100)}%)`;
    row.append(label, track, val);
    bars.append(row);
  }
}

typeInputs.forEach((r) => r.addEventListener("change", fillCategories));

form.addEventListener("submit", (ev) => {
  ev.preventDefault();
  const data = {
    type: selectedType(), description: $("description").value, amount: $("amount").value,
    category: $("category").value, date: $("date").value,
  };
  const { ok, errors } = validateEntry(data);
  for (const f of ["description", "amount", "category", "date"]) $(`err-${f}`).textContent = errors[f] || "";
  if (!ok) return;
  entries.push(createEntry(data));
  save();
  $("description").value = ""; $("amount").value = "";
  $("description").focus();
  render();
});

$("filter-type").addEventListener("change", (e) => { filters.type = e.target.value; render(); });
$("filter-month").addEventListener("change", (e) => { filters.month = e.target.value; render(); });
$("clear-all").addEventListener("click", () => {
  if (entries.length && confirm("Delete all transactions? This cannot be undone.")) { entries = []; save(); render(); }
});

$("date").value = new Date().toISOString().slice(0, 10);
fillCategories();
render();
