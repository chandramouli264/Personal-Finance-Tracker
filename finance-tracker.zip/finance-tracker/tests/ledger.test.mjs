import test from "node:test";
import assert from "node:assert/strict";
import { createEntry, expenseByCategory, filterEntries, totals, validateEntry } from "../js/ledger.js";

const base = { type: "expense", description: "Lunch", amount: "250.50", category: "Food", date: "2026-10-01" };

test("validateEntry accepts a good entry", () => assert.equal(validateEntry(base).ok, true));

test("validateEntry rejects bad input", () => {
  for (const bad of [{ amount: "0" }, { amount: "-5" }, { amount: "abc" }, { amount: "" }, { description: "  " },
                     { category: "Salary" }, { date: "" }, { type: "other" }]) {
    assert.equal(validateEntry({ ...base, ...bad }).ok, false, JSON.stringify(bad));
  }
});

test("totals avoids floating point drift", () => {
  const e = ["0.1", "0.2"].map((a) => createEntry({ ...base, amount: a }));
  assert.equal(totals(e).expense, 0.3);
});

test("totals computes balance", () => {
  const e = [createEntry({ ...base, type: "income", category: "Salary", amount: "50000" }),
             createEntry({ ...base, amount: "1200" })];
  assert.deepEqual(totals(e), { income: 50000, expense: 1200, balance: 48800 });
});

test("expenseByCategory groups, sorts and computes shares", () => {
  const e = [createEntry({ ...base, amount: "300" }), createEntry({ ...base, amount: "100" }),
             createEntry({ ...base, category: "Bills", amount: "100" })];
  const r = expenseByCategory(e);
  assert.equal(r[0].category, "Food"); assert.equal(r[0].amount, 400);
  assert.equal(Math.round(r[0].share * 100), 80);
});

test("filterEntries by type and month, newest first", () => {
  const e = [createEntry({ ...base, date: "2026-09-30" }), createEntry({ ...base, date: "2026-10-05" }),
             createEntry({ ...base, type: "income", category: "Gift", date: "2026-10-02" })];
  assert.equal(filterEntries(e, { month: "2026-10" }).length, 2);
  assert.equal(filterEntries(e, { type: "income" }).length, 1);
  assert.equal(filterEntries(e, {})[0].date, "2026-10-05");
});
